from django.contrib import admin

from .models import Shop, Furniture, Manager
# Register your models here.

admin.site.register(Shop)
admin.site.register(Furniture)
admin.site.register(Manager)
